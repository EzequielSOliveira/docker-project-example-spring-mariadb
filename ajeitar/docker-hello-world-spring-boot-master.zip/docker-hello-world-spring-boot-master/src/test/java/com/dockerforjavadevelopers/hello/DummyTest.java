package com.dockerforjavadevelopers.hello;

import static org.junit.Assert.*;

import org.junit.Test;

public class DummyTest {

  @Test
  public void aTest() {
    assertEquals(true, true);
  }
}
